// pages/index/index.js
import { request, uploadFile } from '../../utils/request.js';
import { uploadAndScore } from '../../utils/api.js';

Page({
  data: {
    stageId: null,           // 当前阶段ID（从页面参数或全局获取）
    userId: null,            // 用户ID
    currentStage: {},        // 当前阶段对象
    scoreResult: null,       // AI 返回的评分结果 { score, commentDetails }
    uploadLoading: false,
    stageTabs: [],           // 阶段标签列表 [{ id, name, disable, completedTasks, totalTasks }]
    unlockStageId: 1         // 当前解锁的阶段ID（默认第一阶段）
  },

  onLoad(options) {
    console.log('=== onLoad 页面加载 ===');
    console.log('传入参数 options:', options);
    
    // 假设从上一页传入 stageId 和 userId
    const stageId = options ? parseInt(options.stageId) || 1 : 1;
    const userId = options ? options.userId || 'default_user' : 'default_user';
    
    console.log('设置 stageId:', stageId, ', userId:', userId);
    
    this.setData({ stageId, userId });
    
    // 加载阶段数据
    this.loadStageData();
    // 加载当前阶段已有数据（可选）
    this.loadStageDetail();
  },

  // 加载阶段数据
  async loadStageData() {
    console.log('=== loadStageData 加载阶段数据 ===');
    try {
      const res = await request({ url: '/api/stages' });
      console.log('后端返回阶段数据:', res);
      
      // 防御性检查：确保返回数据是数组
      if (!Array.isArray(res)) {
        console.error('阶段数据格式错误，期望数组:', res);
        return;
      }
      
      // 设置阶段的 disable 属性，默认初始显示阶段（第一阶段可访问，其他禁用）
      const stageTabs = res.map((stage, index) => ({
        id: stage.id,
        name: stage.name,
        disable: index > 0,  // 默认只有第一阶段可访问
        completedTasks: stage.completedTasks || 0,
        totalTasks: stage.totalTasks || 0
      }));
      
      console.log('处理后的 stageTabs:', stageTabs);
      this.setData({ stageTabs });
    } catch (err) {
      console.error('加载阶段数据失败:', err);
    }
  },

  // 更新阶段标签状态（勾选任务后调用）
  async updateStageTabs(taskId) {
    console.log('=== updateStageTabs 更新阶段标签 ===');
    console.log('传入参数 taskId:', taskId);
    
    const { stageTabs, unlockStageId, currentStage, userId } = this.data;
    console.log('当前数据 - stageTabs:', stageTabs);
    console.log('当前数据 - unlockStageId:', unlockStageId);
    console.log('当前数据 - currentStage:', currentStage);
    
    const currentTabIndex = stageTabs.findIndex(tab => tab.id === currentStage.id);
    console.log('当前阶段索引 currentTabIndex:', currentTabIndex);
    
    if (currentTabIndex === -1) {
      console.error('未找到当前阶段，无法更新');
      return;
    }

    // 创建新的 stageTabs 数组，完成任务+1
    const newStageTabs = [...stageTabs];
    const prevCompleted = newStageTabs[currentTabIndex].completedTasks;
    newStageTabs[currentTabIndex] = {
      ...newStageTabs[currentTabIndex],
      completedTasks: newStageTabs[currentTabIndex].completedTasks + 1
    };

    // 判断是否当前阶段任务全部完成
    const currentTab = newStageTabs[currentTabIndex];
    let newUnlockStageId = unlockStageId;
    
    console.log('当前阶段任务完成情况:', currentTab.completedTasks, '/', currentTab.totalTasks);
    
    if (currentTab.completedTasks >= currentTab.totalTasks && currentTab.id >= unlockStageId) {
      // 当前阶段任务全部完成，解锁下一阶段
      newUnlockStageId = currentTab.id + 1;
      console.log('阶段任务全部完成，解锁下一阶段:', newUnlockStageId);
      
      // 更新下一阶段的 disable 属性
      const nextTabIndex = currentTabIndex + 1;
      if (nextTabIndex < newStageTabs.length) {
        newStageTabs[nextTabIndex] = {
          ...newStageTabs[nextTabIndex],
          disable: false
        };
        console.log('已解锁阶段:', newStageTabs[nextTabIndex].name);
      }
    } else {
      console.log('阶段任务未全部完成或不是当前解锁阶段');
    }

    // 更新界面显示
    this.setData({
      stageTabs: newStageTabs,
      unlockStageId: newUnlockStageId
    });
    console.log('更新后的 stageTabs:', newStageTabs);

    // 上传任务状态变更到后端保存
    try {
      console.log('开始保存任务状态到后端...');
      const saveRes = await request({
        url: '/api/task/update',
        method: 'POST',
        data: {
          taskId,
          stageId: currentStage.id,
          userId,
          completed: true
        }
      });
      console.log('任务状态保存成功:', saveRes);
    } catch (err) {
      console.error('更新任务状态失败:', err);
    }
  },

  // 任务勾选处理
  handleTaskCheck(e) {
    console.log('=== handleTaskCheck 任务勾选 ===');
    const { taskId } = e.currentTarget.dataset;
    console.log('用户勾选任务 taskId:', taskId);
    this.updateStageTabs(taskId);
  },

  // 切换阶段
  switchStage(e) {
    console.log('=== switchStage 切换阶段 ===');
    const { stageId } = e.currentTarget.dataset;
    const targetStageId = parseInt(stageId);
    console.log('用户尝试切换到阶段:', targetStageId);
    
    const { stageTabs } = this.data;
    const stage = stageTabs.find(tab => tab.id === targetStageId);
    console.log('目标阶段信息:', stage);
    
    // 如果阶段被禁用，不允许切换
    if (stage && !stage.disable) {
      console.log('阶段可访问，切换到阶段:', targetStageId);
      this.setData({ stageId: targetStageId });
      this.loadStageDetail();
    } else if (stage && stage.disable) {
      console.log('阶段被禁用，无法切换');
      wx.showToast({ title: '请先完成前一阶段', icon: 'none' });
    } else {
      console.error('未找到目标阶段:', targetStageId);
    }
  },

  // 加载阶段详情（包含已有评分等）
  async loadStageDetail() {
    console.log('=== loadStageDetail 加载阶段详情 ===');
    console.log('当前 stageId:', this.data.stageId);
    
    // 防御性检查：确保 stageId 有效
    if (!this.data.stageId || isNaN(this.data.stageId)) {
      console.error('无效的 stageId:', this.data.stageId);
      return;
    }
    
    try {
      const res = await request({ url: `/api/stage/detail?stageId=${this.data.stageId}` });
      console.log('阶段详情数据:', res);
      
      // 防御性检查：确保返回数据有效
      if (!res || typeof res !== 'object') {
        console.error('阶段详情数据格式错误:', res);
        return;
      }
      
      this.setData({ currentStage: res });
      
      if (res.aiScore !== undefined && res.aiScore !== null) {
        // 如果已有评分，直接渲染
        console.log('已有 AI 评分:', res.aiScore);
        this.setData({
          scoreResult: { score: res.aiScore, commentDetails: res.aiComment || {} }
        });
      }
    } catch (err) {
      console.error('加载阶段详情失败:', err);
    }
  },

  // 选择文件并上传（业务文件 + AI 分析）
  async handleUploadAndScore() {
    console.log('=== handleUploadAndScore 文件上传与AI分析 ===');
    console.log('当前 stageId:', this.data.stageId, ', userId:', this.data.userId);
    
    // 1. 选择文件（支持图片、PDF等）
    wx.chooseMedia({
      count: 1,
      mediaType: ['image', 'file'],
      sourceType: ['album', 'camera'],
      success: async (res) => {
        console.log('文件选择成功:', res);
        const filePath = res.tempFiles[0].tempFilePath;
        console.log('文件路径:', filePath);
        
        this.setData({ uploadLoading: true });
        wx.showLoading({ title: '上传并分析中...', mask: true });

        try {
          // 2. 先上传到 Spring Boot 业务后端（保存文件）
          console.log('开始上传文件到 Spring Boot...');
          const uploadResult = await uploadFile(filePath, {
            stageId: this.data.stageId,
            userId: this.data.userId
          });
          console.log('Spring Boot 上传结果:', uploadResult);
          const filename = uploadResult.fileName; // 假设返回文件名
          console.log('文件名:', filename);

          // 3. 调用 AI 后端分析同一个文件
          console.log('开始调用 AI 分析...');
          const aiResult = await uploadAndScore(filePath);
          console.log('AI 分析结果:', aiResult);
          const { score, commentDetails } = aiResult;
          console.log('评分:', score, ', 详情:', commentDetails);

          // 4. 渲染 AI 评分结果到界面
          this.setData({
            scoreResult: { score, commentDetails }
          });
          console.log('已更新界面评分显示');

          // 5. 保存 AI 评分到数据库（通过 Spring Boot）
          console.log('开始保存评分到数据库...');
          await this.saveAiScoreToDatabase(
            this.data.stageId,
            this.data.userId,
            score,
            commentDetails,
            filename
          );
          console.log('评分保存成功');

          // 6. 更新当前阶段数据，将分数渲染回当前阶段
          this.setData({
            currentStage: {
              ...this.data.currentStage,
              aiScore: score,
              aiComment: commentDetails
            }
          });
          console.log('已更新当前阶段数据');

          wx.showToast({ title: '分析与保存成功', icon: 'success' });
        } catch (err) {
          console.error('流程失败:', err);
          wx.showToast({ title: '操作失败', icon: 'none' });
        } finally {
          this.setData({ uploadLoading: false });
          wx.hideLoading();
          console.log('上传流程结束');
        }
      },
      fail: (err) => {
        console.error('选择文件失败:', err);
      }
    });
  },

  // 保存 AI 评分到数据库（调用 Spring Boot 接口）
  async saveAiScoreToDatabase(stageId, userId, score, comment, filename) {
    console.log('=== saveAiScoreToDatabase 保存评分 ===');
    console.log('参数 - stageId:', stageId, ', userId:', userId);
    console.log('参数 - score:', score, ', filename:', filename);
    console.log('参数 - comment:', comment);
    
    // 将 comment 对象转为 JSON 字符串存储（取决于后端设计）
    const commentJson = JSON.stringify(comment);
    console.log('转换后的 comment JSON:', commentJson);
    
    const res = await request({
      url: '/api/ai/save-score',
      method: 'POST',
      data: {
        stageId,
        userId,
        score,
        comment: commentJson,
        filename
      }
    });
    
    console.log('保存评分结果:', res);
    return res;
  }
});