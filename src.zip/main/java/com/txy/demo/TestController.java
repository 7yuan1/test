package com.txy.demo;

import com.txy.demo.demos.web.User;
import com.txy.demo.exception.BusinessException;
import com.txy.demo.exception.ResourceNotFoundException;
import com.txy.demo.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/user")
public class TestController {

    private final UserService userService;

    public TestController(@Qualifier("demoUserService") UserService userService) {
        this.userService = userService;
    }

    /**
     * 查询所有用户 - 使用统一响应
     */
    @GetMapping("/list")
    public Result<List<User>> list() {
        List<User> userList = userService.list();
        return Result.success(userList);
    }

    /**
     * 根据ID查询用户
     */
    @GetMapping("/{id}")
    public Result<User> getById(@PathVariable Integer id) {
        log.info("查询用户, id: {}", id);
        // 参数验证
        if (id == null || id <= 0) {
            throw new BusinessException(400, "用户ID不合法");
        }
        User user = userService.getById(id);
        // 业务判断
        if (user == null) {
            throw new ResourceNotFoundException("用户不存在，id: " + id);
        }
        return Result.success(user);
    }

    /**
     * 添加用户
     */
    @PostMapping("/add")
    public Result<Void> add(@RequestBody User user) {
        boolean saved = userService.save(user);
        if (saved) {
            return Result.success("添加成功", null);
        } else {
            return Result.error("添加失败");
        }
    }

    /**
     * 模拟除零异常（测试全局异常处理）
     */
    @GetMapping("/test/exception")
    public Result<Void> testException() {
        int a = 1 / 0; // 会抛出ArithmeticException
        return Result.success();
    }
}