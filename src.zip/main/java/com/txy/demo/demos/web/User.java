package com.txy.demo.demos.web;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import org.apache.ibatis.type.Alias;

@Data
@TableName("user")
@Alias("DemoUser")
public class User {
    @TableId(type = IdType.AUTO)
    private Integer userId;

    // 映射数据库中的 user_name 字段
    @TableField("user_name")
    private String name;
    
    @TableField("user_account")
    private String userAccount;
    
    @TableField("user_password")
    private String userPassword;
    
    @TableField("user_img")
    private String userImg;
    
    @TableField("stage_id")
    private Integer stageId;
}