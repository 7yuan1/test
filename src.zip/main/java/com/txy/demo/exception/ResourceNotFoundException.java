package com.txy.demo.exception;

import lombok.EqualsAndHashCode;

/**
 * 资源未找到异常
 */
@EqualsAndHashCode(callSuper = true)
public class ResourceNotFoundException extends BusinessException {
    
    public ResourceNotFoundException(String message) {
        super(404, message);
    }
}
