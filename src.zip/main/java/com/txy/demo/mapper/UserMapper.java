package com.txy.demo.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.txy.demo.demos.web.User;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Repository("demoUserMapper")
@Mapper
public interface UserMapper extends BaseMapper<User> {
}
