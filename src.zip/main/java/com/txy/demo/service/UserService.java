package com.txy.demo.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.txy.demo.demos.web.User;

public interface UserService extends IService<User> {
}
