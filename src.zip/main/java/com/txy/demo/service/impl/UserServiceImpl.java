package com.txy.demo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.txy.demo.demos.web.User;
import com.txy.demo.mapper.UserMapper;
import com.txy.demo.service.UserService;
import org.springframework.stereotype.Service;

@Service("demoUserService")
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
}
