package com.txy.hanjiapeixun.config;

import com.txy.hanjiapeixun.interceptor.LoginInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web配置类
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {
    
    @Autowired
    private LoginInterceptor loginInterceptor;
    
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(loginInterceptor)
                .addPathPatterns("/api/**") // 拦截所有/api/下的请求
                .excludePathPatterns( // 排除以下路径
                        "/api/user/login",      // 登录接口
                        "/api/user/register",   // 注册接口
                        "/api/file/download/**" // 文件下载（如需要）
                );
    }
}
