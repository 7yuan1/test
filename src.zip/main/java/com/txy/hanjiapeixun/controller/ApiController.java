package com.txy.hanjiapeixun.controller;

import com.txy.hanjiapeixun.config.UploadConfig;
import com.txy.hanjiapeixun.entity.*;
import com.txy.hanjiapeixun.service.AttachmentService;
import com.txy.hanjiapeixun.service.UserTaskService;
import com.txy.hanjiapeixun.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

/**
 * 统一API控制器
 * 包含所有接口
 */
@Slf4j
@RestController
@RequestMapping("/api")
public class ApiController {
    
    private final UserTaskService userTaskService;
    private final AttachmentService attachmentService;
    private final UploadConfig uploadConfig;
    
    public ApiController(UserTaskService userTaskService,
                        AttachmentService attachmentService,
                        UploadConfig uploadConfig) {
        this.userTaskService = userTaskService;
        this.attachmentService = attachmentService;
        this.uploadConfig = uploadConfig;
    }
    
    // ==================== 文件上传接口 ====================
    
    /**
     * 文件上传
     * POST /api/file/upload
     */
    @RequestMapping("/file/upload")
    public Result uploadFile(@RequestParam("file") MultipartFile file,
                             @RequestParam("stageId") int stageId) {
        try {
            // 1. 检查文件是否为空
            if (file.isEmpty()) {
                return new Result(400, "文件为空", null);
            }

            // 2. 确保上传目录存在
            File uploadDir = new File(uploadConfig.getFilePath());
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();  // 创建目录（包含父目录）
            }

            // 3. 生成唯一文件名（时间戳 + 原文件名，避免重名覆盖）
            String fileName = new Date().getTime() + "-" + file.getOriginalFilename();
            String filePath = uploadConfig.getFilePath() + File.separator + fileName;

            // 4. 保存文件到磁盘
            File dest = new File(filePath);
            file.transferTo(dest);  // Spring提供的便捷方法

            // 5. 计算并格式化文件大小
            long fileSize = file.getSize();
            String sizeStr = formatFileSize(fileSize);

            // 6. 保存附件信息到数据库
            Attachment attachment = new Attachment();
            attachment.setAttachmentName(file.getOriginalFilename());
            attachment.setAttachmentSize(sizeStr);
            attachment.setAttachmentType("file");
            attachment.setAttachmentUrl("/api/file/download?fileName=" + fileName);
            attachment.setStageId(stageId);
            attachmentService.save(attachment);

            return new Result(200, "上传成功", attachment);
            
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(500, "上传失败: " + e.getMessage(), null);
        }
    }

    /**
     * 格式化文件大小
     */
    private String formatFileSize(long size) {
        if (size < 1024) {
            return size + "B";
        } else if (size < 1024 * 1024) {
            return String.format("%.2f", size / 1024.0) + "KB";
        } else {
            return String.format("%.2f", size / (1024.0 * 1024.0)) + "MB";
        }
    }

    /**
     * 文件下载
     * GET /api/file/download?fileName=xxx
     */
    @RequestMapping("/file/download")
    public void downloadFile(@RequestParam("fileName") String fileName,
                              HttpServletResponse response) {
        FileInputStream fis = null;
        OutputStream os = null;
        
        try {
            // 1. 构建文件路径
            String filePath = uploadConfig.getFilePath() + File.separator + fileName;
            File file = new File(filePath);

            // 2. 检查文件是否存在
            if (!file.exists()) {
                response.setStatus(404);
                return;
            }

            // 3. 设置响应头
            response.setContentType("application/octet-stream");  // 二进制流
            response.setContentLength((int) file.length());       // 文件大小
            // 设置下载文件名（解决中文乱码）
            response.setHeader("Content-Disposition",
                "attachment; filename=" + URLEncoder.encode(file.getName(), "UTF-8"));

            // 4. 读取文件并写入响应
            fis = new FileInputStream(file);
            os = response.getOutputStream();

            byte[] buffer = new byte[1024];  // 1KB缓冲区
            int len;
            while ((len = fis.read(buffer)) != -1) {
                os.write(buffer, 0, len);
            }
            
            os.flush();
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // 5. 关闭流
            try {
                if (fis != null) fis.close();
                if (os != null) os.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 文件删除
     * POST /api/file/delete?id=xxx
     */
    @RequestMapping("/file/delete")
    public Result deleteFile(@RequestParam("id") int attachmentId) {
        try {
            // 1. 获取附件信息
            Attachment attachment = attachmentService.getById(attachmentId);
            if (attachment == null) {
                return new Result(404, "附件不存在", null);
            }

            // 2. 从URL中提取文件名
            String url = attachment.getAttachmentUrl();
            String fileName = url.substring(url.indexOf("fileName=") + 9);
            String filePath = uploadConfig.getFilePath() + File.separator + fileName;
            
            // 3. 删除物理文件
            File file = new File(filePath);
            if (file.exists()) {
                file.delete();
            }

            // 4. 删除数据库记录
            attachmentService.removeById(attachmentId);

            return new Result(200, "删除成功", null);
            
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(500, "删除失败: " + e.getMessage(), null);
        }
    }
    
    // ==================== 用户任务相关接口 ====================
    
    /**
     * 获取用户任务列表（根据阶段）
     * GET /api/usertask/list/{userId}/{stageId}
     */
    @GetMapping("/usertask/list/{userId}/{stageId}")
    public Result<List<UserTask>> getUserTaskList(@PathVariable int userId, 
                                                   @PathVariable int stageId) {
        log.info("查询用户任务列表，userId: {}, stageId: {}", userId, stageId);
        List<UserTask> userTasks = userTaskService.getByUserIdAndStageId(userId, stageId);
        return Result.success(userTasks);
    }
    
    /**
     * 获取用户单个任务状态
     * GET /api/usertask/{userId}/{taskId}
     */
    @GetMapping("/usertask/{userId}/{taskId}")
    public Result<UserTask> getUserTask(@PathVariable int userId,
                                        @PathVariable int taskId) {
        log.info("查询用户任务，userId: {}, taskId: {}", userId, taskId);
        UserTask userTask = userTaskService.getByUserIdAndTaskId(userId, taskId);
        if (userTask == null) {
            return Result.error(404, "任务不存在");
        }
        return Result.success(userTask);
    }
    
    /**
     * 更新任务状态（使用updateTaskStatus方法）
     * PUT /api/usertask/update
     */
    @PutMapping("/usertask/update")
    public Result<Void> updateTaskStatus(@RequestBody UserTask userTask) {
        log.info("更新任务状态，userId: {}, taskId: {}, completed: {}", 
                userTask.getUserId(), userTask.getTaskId(), userTask.getCompleted());
        
        // 参数校验
        if (userTask.getUserId() == null || userTask.getTaskId() == null || userTask.getCompleted() == null) {
            return Result.error(400, "用户ID、任务ID和完成状态不能为空");
        }
        
        // 调用UserTaskService的updateTaskStatus方法（内部已实现存在则更新，不存在则新增的逻辑）
        boolean success = userTaskService.updateTaskStatus(
                userTask.getUserId(), 
                userTask.getTaskId(), 
                userTask.getCompleted());
        
        if (success) {
            return Result.success("更新成功", null);
        } else {
            return Result.error("更新失败");
        }
    }
    
    // ==================== 附件相关接口 ====================
    
    /**
     * 获取阶段附件列表
     * GET /api/attachment/list/stage/{stageId}
     */
    @GetMapping("/attachment/list/stage/{stageId}")
    public Result<List<Attachment>> getStageAttachments(@PathVariable Integer stageId) {
        log.info("查询阶段附件列表，stageId: {}", stageId);
        List<Attachment> attachments = attachmentService.listByStageId(stageId);
        return Result.success(attachments);
    }
    
    /**
     * 删除附件
     * DELETE /api/attachment/{id}
     */
    @DeleteMapping("/attachment/{id}")
    public Result<Void> deleteAttachment(@PathVariable Integer id) {
        log.info("删除附件，id: {}", id);
        
        if (id == null || id <= 0) {
            return Result.error(400, "附件ID不合法");
        }
        
        boolean success = attachmentService.removeById(id);
        if (success) {
            return Result.success("删除成功", null);
        } else {
            return Result.error(404, "附件不存在");
        }
    }
}
