package com.txy.hanjiapeixun.controller;

import com.txy.hanjiapeixun.entity.Attachment;
import com.txy.hanjiapeixun.service.AttachmentService;
import com.txy.hanjiapeixun.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 文件上传控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/file")
public class FileUploadController {
    
    @Autowired
    private AttachmentService attachmentService;
    
    /**
     * 文件存储路径（从配置文件注入）
     */
    @Value("${upload.filePath:D:/project_files/hanjia}")
    private String uploadPath;
    
    /**
     * 允许的最大文件大小（10MB）
     */
    private static final long MAX_FILE_SIZE = 10 * 1024 * 1024;
    
    /**
     * 允许的文件类型
     */
    private static final String[] ALLOWED_TYPES = {
        "image/jpeg", "image/png", "image/gif", "image/bmp",
        "application/pdf",
        "application/msword", 
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "text/plain"
    };
    
    /**
     * 文件上传
     * POST /api/file/upload
     */
    @PostMapping("/upload")
    public Result<Map<String, Object>> uploadFile(
            @RequestParam("file") MultipartFile file,
            @RequestParam("stageId") int stageId,
            HttpServletRequest request) {
        
        try {
            // 1. 获取用户ID（从拦截器设置的属性中获取）
            Integer userId = (Integer) request.getAttribute("userId");
            if (userId == null) {
                return Result.error(401, "未登录或Token无效");
            }
            
            log.info("文件上传请求，userId: {}, stageId: {}, fileName: {}", 
                    userId, stageId, file.getOriginalFilename());
            
            // 2. 检查文件是否为空
            if (file.isEmpty()) {
                return Result.error(400, "文件为空");
            }
            
            // 3. 检查文件大小
            if (file.getSize() > MAX_FILE_SIZE) {
                return Result.error(400, "文件大小不能超过10MB");
            }
            
            // 4. 检查文件类型
            String contentType = file.getContentType();
            if (contentType != null && !isAllowedType(contentType)) {
                return Result.error(400, "不支持的文件类型");
            }
            
            // 5. 确保上传目录存在（按日期分目录存储）
            String dateFolder = new SimpleDateFormat("yyyyMMdd").format(new Date());
            String dirPath = uploadPath + File.separator + dateFolder;
            File uploadDir = new File(dirPath);
            if (!uploadDir.exists()) {
                boolean created = uploadDir.mkdirs();
                if (!created) {
                    log.error("创建上传目录失败: {}", dirPath);
                    return Result.error(500, "创建上传目录失败");
                }
            }
            
            // 6. 生成唯一文件名（UUID + 原文件扩展名）
            String originalFilename = file.getOriginalFilename();
            String extension = "";
            if (originalFilename != null && originalFilename.contains(".")) {
                extension = originalFilename.substring(originalFilename.lastIndexOf("."));
            }
            String fileName = System.currentTimeMillis() + "_" + 
                            java.util.UUID.randomUUID().toString().substring(0, 8) + extension;
            String filePath = dirPath + File.separator + fileName;
            
            // 7. 保存文件到磁盘
            File dest = new File(filePath);
            file.transferTo(dest);
            log.info("文件保存成功: {}", filePath);
            
            // 8. 构建附件信息 - 使用新的字段名
            Attachment attachment = new Attachment();
            attachment.setAttachmentName(originalFilename);
            attachment.setAttachmentPath("/uploads/" + dateFolder + "/" + fileName);
            attachment.setAttachmentType("file");  // 文件类型: file/link/ai_tool
            attachment.setAttachmentSize(formatFileSize(file.getSize()));  // 格式化后的大小字符串
            attachment.setAttachmentUrl("/api/file/download?fileName=" + fileName);  // 访问URL
            attachment.setStageId(stageId);
            attachment.setUserId(userId);
            
            // 9. 保存附件信息到数据库
            attachmentService.save(attachment);
            log.info("附件信息保存成功，attachmentId: {}", attachment.getAttachmentId());
            
            // 10. 构建响应数据 - 使用新的字段名
            Map<String, Object> responseData = new HashMap<>();
            responseData.put("attachmentId", attachment.getAttachmentId());
            responseData.put("attachmentName", attachment.getAttachmentName());
            responseData.put("attachmentPath", attachment.getAttachmentPath());
            responseData.put("attachmentSize", attachment.getAttachmentSize());
            responseData.put("attachmentType", attachment.getAttachmentType());
            responseData.put("attachmentUrl", attachment.getAttachmentUrl());
            responseData.put("uploadTime", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            
            return Result.success("上传成功", responseData);
            
        } catch (IOException e) {
            log.error("文件上传失败", e);
            return Result.error(500, "上传失败: " + e.getMessage());
        } catch (Exception e) {
            log.error("文件上传异常", e);
            return Result.error(500, "上传失败: " + e.getMessage());
        }
    }
    
    /**
     * 删除文件
     * DELETE /api/file/delete/{attachmentId}
     */
    @DeleteMapping("/delete/{attachmentId}")
    public Result deleteFile(
            @PathVariable Integer attachmentId,
            HttpServletRequest request) {
        
        try {
            // 1. 获取用户ID
            Integer userId = (Integer) request.getAttribute("userId");
            if (userId == null) {
                return Result.error(401, "未登录或Token无效");
            }
            
            log.info("删除文件请求，userId: {}, attachmentId: {}", userId, attachmentId);
            
            // 2. 查询附件信息
            Attachment attachment = attachmentService.getById(attachmentId);
            if (attachment == null) {
                return Result.error(404, "附件不存在");
            }
            
            // 3. 验证权限（只能删除自己的文件）
            if (!attachment.getUserId().equals(userId)) {
                return Result.error(403, "无权删除此文件");
            }
            
            // 4. 删除物理文件 - 使用新的字段名
            String fullPath = uploadPath + attachment.getAttachmentPath().replace("/uploads", "");
            File file = new File(fullPath);
            if (file.exists()) {
                boolean deleted = file.delete();
                if (!deleted) {
                    log.warn("删除物理文件失败: {}", fullPath);
                }
            }
            
            // 5. 删除数据库记录
            attachmentService.removeById(attachmentId);
            log.info("文件删除成功，attachmentId: {}", attachmentId);
            
            return Result.success("删除成功", null);
            
        } catch (Exception e) {
            log.error("删除文件失败", e);
            return Result.error(500, "删除失败: " + e.getMessage());
        }
    }
    
    /**
     * 获取阶段附件列表
     * GET /api/file/list?stageId=1
     */
    @GetMapping("/list")
    public Result listFiles(
            @RequestParam int stageId,
            HttpServletRequest request) {
        
        // 1. 获取用户ID
        Integer userId = (Integer) request.getAttribute("userId");
        if (userId == null) {
            return Result.error(401, "未登录或Token无效");
        }
        
        log.info("查询附件列表，userId: {}, stageId: {}", userId, stageId);
        
        // 2. 查询附件列表
        java.util.List<Attachment> attachments = attachmentService.getByStageIdAndUserId(stageId, userId);
        
        return Result.success(attachments);
    }
    
    /**
     * 检查文件类型是否允许
     */
    private boolean isAllowedType(String contentType) {
        for (String allowedType : ALLOWED_TYPES) {
            if (allowedType.equals(contentType)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 格式化文件大小
     */
    private String formatFileSize(long size) {
        if (size < 1024) {
            return size + "B";
        } else if (size < 1024 * 1024) {
            return String.format("%.2fKB", size / 1024.0);
        } else if (size < 1024 * 1024 * 1024) {
            return String.format("%.2fMB", size / (1024.0 * 1024.0));
        } else {
            return String.format("%.2fGB", size / (1024.0 * 1024.0 * 1024.0));
        }
    }
}
