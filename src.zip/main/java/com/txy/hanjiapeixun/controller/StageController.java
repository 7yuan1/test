package com.txy.hanjiapeixun.controller;

import com.txy.hanjiapeixun.entity.Attachment;
import com.txy.hanjiapeixun.entity.StageVO;
import com.txy.hanjiapeixun.entity.TaskVO;
import com.txy.hanjiapeixun.entity.UserTask;
import com.txy.hanjiapeixun.service.AttachmentService;
import com.txy.hanjiapeixun.service.StageService;
import com.txy.hanjiapeixun.service.UserTaskService;
import com.txy.hanjiapeixun.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 阶段控制器
 */
@Slf4j
@RestController
@RequestMapping("/api/stage")
public class StageController {
    
    @Autowired
    private StageService stageService;
    
    @Autowired
    private UserTaskService userTaskService;
    
    @Autowired
    private AttachmentService attachmentService;
    
    /**
     * 获取用户所有阶段数据（需要认证）
     * GET /api/stage/list
     */
    @GetMapping("/list")
    public Result<List<StageVO>> getUserStages(HttpServletRequest request) {
        // 从拦截器设置的属性中获取userId
        Integer userId = (Integer) request.getAttribute("userId");
        
        if (userId == null) {
            return Result.error(401, "未登录或Token无效");
        }
        
        log.info("查询用户阶段数据，userId: {}", userId);
        List<StageVO> stages = stageService.getUserStages(userId);
        return Result.success(stages);
    }
    
    /**
     * 获取指定阶段的任务列表（需要认证）
     * GET /api/stage/{stageId}/tasks
     */
    @GetMapping("/{stageId}/tasks")
    public Result<List<TaskVO>> getStageTasks(
            @PathVariable Integer stageId,
            HttpServletRequest request) {
        
        Integer userId = (Integer) request.getAttribute("userId");
        
        if (userId == null) {
            return Result.error(401, "未登录或Token无效");
        }
        
        log.info("查询阶段任务，stageId: {}, userId: {}", stageId, userId);
        List<TaskVO> tasks = stageService.getStageTasks(stageId, userId);
        return Result.success(tasks);
    }
    
    /**
     * 获取阶段详情（包含任务状态映射和附件信息）
     * GET /api/stage/detail?stageId=1&userId=1
     */
    @GetMapping("/detail")
    public Result<Map<String, Object>> getStageDetail(
            @RequestParam int stageId,
            @RequestParam(defaultValue = "1") int userId) {
        
        log.info("查询阶段详情，stageId: {}, userId: {}", stageId, userId);
        
        // 1. 获取阶段基本信息
        com.txy.hanjiapeixun.entity.Stage stage = stageService.getById(stageId);
        if (stage == null) {
            return Result.error(404, "阶段不存在");
        }
        
        // 2. 获取该阶段的所有任务（已包含完成状态）
        List<TaskVO> tasks = stageService.getStageTasks(stageId, userId);
        
        // 3. 构建任务ID到完成状态的映射
        Map<Integer, Integer> taskStatusMap = new HashMap<>();
        for (TaskVO task : tasks) {
            taskStatusMap.put(task.getTaskId(), task.getCompleted());
        }
        
        // 4. 获取用户在该阶段的附件列表
        List<Attachment> attachments = attachmentService.getByStageIdAndUserId(stageId, userId);
        
        // 5. 计算统计信息
        long completedCount = taskStatusMap.values().stream()
                .filter(status -> status == 1)
                .count();
        
        // 6. 返回阶段详情（含任务列表和完成状态）
        Map<String, Object> detail = new HashMap<>();
        detail.put("stage", stage);
        detail.put("tasks", tasks);
        detail.put("taskStatusMap", taskStatusMap);
        detail.put("attachments", attachments);
        detail.put("totalTasks", tasks.size());
        detail.put("completedTasks", completedCount);
        
        log.info("查询到 {} 条任务记录，已完成 {} 条，{} 个附件", 
                tasks.size(), completedCount, attachments.size());
        
        return Result.success(detail);
    }
    
    /**
     * 更新任务状态
     * PUT /api/stage/task/updateStatus
     */
    @PutMapping("/task/updateStatus")
    public Result updateTaskStatus(@RequestBody UserTask userTask) {
        log.info("更新任务状态，userId: {}, taskId: {}, completed: {}", 
                userTask.getUserId(), userTask.getTaskId(), userTask.getCompleted());
        
        // 参数验证
        if (userTask.getUserId() == null || userTask.getTaskId() == null) {
            return Result.error(400, "用户ID和任务ID不能为空");
        }
        
        if (userTask.getCompleted() == null || (userTask.getCompleted() != 0 && userTask.getCompleted() != 1)) {
            return Result.error(400, "完成状态只能是0或1");
        }
        
        // 先查询是否存在记录
        UserTask existingTask = userTaskService.getByUserIdAndTaskId(
                userTask.getUserId(), userTask.getTaskId());
        
        boolean result;
        if (existingTask == null) {
            // 不存在则新增
            log.info("用户任务记录不存在，创建新记录");
            result = userTaskService.save(userTask);
        } else {
            // 存在则更新
            log.info("用户任务记录存在，更新完成状态");
            com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper<UserTask> updateWrapper = 
                    new com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper<>();
            updateWrapper.eq(UserTask::getUserId, userTask.getUserId())
                        .eq(UserTask::getTaskId, userTask.getTaskId())
                        .set(UserTask::getCompleted, userTask.getCompleted());
            result = userTaskService.update(updateWrapper);
        }
        
        log.info("更新任务状态结果: {}", result);
        
        if (result) {
            return Result.success("更新成功", null);
        } else {
            return Result.error("更新失败");
        }
    }
}
