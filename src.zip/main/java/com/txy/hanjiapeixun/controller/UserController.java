package com.txy.hanjiapeixun.controller;

import com.txy.hanjiapeixun.dto.LoginRequest;
import com.txy.hanjiapeixun.dto.LoginResponse;
import com.txy.hanjiapeixun.entity.User;
import com.txy.demo.exception.ResourceNotFoundException;
import com.txy.demo.exception.BusinessException;
import com.txy.hanjiapeixun.service.UserService;
import com.txy.hanjiapeixun.util.JwtUtil;
import com.txy.hanjiapeixun.util.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;
/**
 * 用户控制器
 * 提供用户相关的RESTful接口
 */
@Slf4j
@RestController
@RequestMapping("/api/user")
public class UserController {
    
    private final UserService userService;
    private final JwtUtil jwtUtil;
    
    public UserController(@Qualifier("hanjiaUserService") UserService userService, 
                         JwtUtil jwtUtil) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
    }
    /**
     * 用户登录
     * POST /api/user/login
     */
    @PostMapping("/login")
    public Result<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
        log.info("登录请求：{}", loginRequest.getUserAccount());
        
        // 1. 参数校验
        if (loginRequest.getUserAccount() == null || loginRequest.getUserAccount().trim().isEmpty()) {
            return Result.error(400, "账号不能为空");
        }
        if (loginRequest.getUserPassword() == null || loginRequest.getUserPassword().trim().isEmpty()) {
            return Result.error(400, "密码不能为空");
        }
        
        // 2. 查询用户
        User user = userService.getByAccount(loginRequest.getUserAccount());
        
        // 3. 验证密码（实际应用中应使用加密比较）
        if (user == null) {
            return Result.error(401, "用户不存在");
        }
        if (!loginRequest.getUserPassword().equals(user.getUserPassword())) {
            return Result.error(401, "密码错误");
        }
        
        // 4. 生成Token
        String token = jwtUtil.generateToken(user.getUserId(), user.getUserName());
        
        // 5. 返回登录结果
        LoginResponse response = new LoginResponse(
                token,
                user.getUserId(),
                user.getUserName(),
                user.getStageId()
        );
        
        log.info("用户登录成功：{}", user.getUserName());
        return Result.success(response);
    }

    /**
     * 获取当前用户信息（需要认证）
     * GET /api/user/info
     * 请求头中必须携带 Authorization: Bearer <token>
     */
    @GetMapping("/info")
    public Result<User> getUserInfo(@RequestHeader("Authorization") String token) {
        // 拦截器已验证Token，可直接使用
        String tokenValue = token.replace("Bearer ", "");
        Integer userId = jwtUtil.getUserIdFromToken(tokenValue);
        
        User user = userService.getById(userId);
        
        if (user == null) {
            return Result.error(404, "用户不存在");
        }
        
        // 清除密码信息
        user.setUserPassword(null);
        return Result.success(user);
    }

    /**
     * 查询所有用户
     * GET /user/list
     */
    @GetMapping("/list")
    public Result<List<User>> list() {
        log.info("请求：查询所有用户");
        List<User> userList = userService.list();
        log.info("查询到 {} 条用户记录", userList.size());
        return Result.success(userList);
    }
    /**
     * 根据ID查询用户
     * GET /user/{id}
     */
    @GetMapping("/{id}")
    public Result<User> getById(@PathVariable Integer id) {
        log.info("请求：根据ID查询用户, id: {}", id);
        // 参数验证
        if (id == null || id <= 0) {
            throw new BusinessException(400, "用户ID不合法");
        }
        User user = userService.getById(id);
        // 业务验证
        if (user == null) {
            throw new ResourceNotFoundException("用户不存在，id: " + id);
        }
        log.info("查询到用户: {}", user.getUserName());
        return Result.success(user);
    }
    /**
     * 根据账号查询用户
     * GET /user/account/{account}
     */
    @GetMapping("/account/{account}")
    public Result<User> getByAccount(@PathVariable String account) {
        log.info("请求：根据账号查询用户, account: {}", account);
        // 使用自定义Mapper方法
        User user = userService.getByAccount(account);
        if (user == null) {
            return Result.error(404, "用户不存在");
        }
        return Result.success(user);
    }
    /**
     * 根据阶段查询用户
     * GET /user/stage/{stageId}
     */
    @GetMapping("/stage/{stageId}")
    public Result<List<User>> getByStageId(@PathVariable Integer stageId) {
        log.info("请求：根据阶段查询用户, stageId: {}", stageId);
        List<User> userList = userService.getByStageId(stageId);
        return Result.success(userList);
    }
/**
 * 添加用户
 * POST /user/add
 */
@PostMapping("/add")
public Result<Void> add(@RequestBody User user) {
    log.info("请求：添加用户, user: {}", user);
    // 参数验证
    if (user.getUserName() == null || user.getUserName().trim().isEmpty()) {
        throw new BusinessException(400, "用户名不能为空");
    }
    if (user.getUserAccount() == null ||
            user.getUserAccount().trim().isEmpty()) {
        throw new BusinessException(400, "账号不能为空");
    }
    boolean saved = userService.save(user);
    log.info("用户添加结果: {}, 生成ID: {}", saved, user.getUserId());
    return Result.success("添加成功", null);
}
    /**
     * 更新用户
     * PUT /user/update
     */
    @PutMapping("/update")
    public Result<Void> update(@RequestBody User user) {
        log.info("请求：更新用户, user: {}", user);
        if (user.getUserId() == null) {
            throw new BusinessException(400, "用户ID不能为空");
        }
        boolean updated = userService.updateById(user);
        if (!updated) {
            throw new ResourceNotFoundException("用户不存在，id: " +
                    user.getUserId());
        }
        return Result.success("更新成功", null);
    }
    /**
     * 删除用户
     * DELETE /user/{id}
     */
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Integer id) {
        log.info("请求：删除用户, id: {}", id);
        boolean removed = userService.removeById(id);
        if (!removed) {
            throw new ResourceNotFoundException("用户不存在，id: " + id);
        }
        return Result.success("删除成功", null);
    }
    /**
     * 测试异常处理
     * GET /user/test/error
     */
    @GetMapping("/test/error")
    public Result<Void> testError() {
        throw new RuntimeException("测试异常");
    }
}

