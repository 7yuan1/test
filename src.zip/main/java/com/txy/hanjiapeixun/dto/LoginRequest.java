package com.txy.hanjiapeixun.dto;

import lombok.Data;

/**
 * 登录请求DTO
 */
@Data
public class LoginRequest {
    private String userAccount;
    private String userPassword;
}
