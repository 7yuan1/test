package com.txy.hanjiapeixun.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 登录响应DTO
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginResponse {
    private String token;      // JWT令牌
    private Integer userId;    // 用户ID
    private String userName;   // 用户名称
    private Integer stageId;   // 当前阶段ID
}
