package com.txy.hanjiapeixun.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("attachment")
public class Attachment {
    
    @TableId(type = IdType.AUTO)
    private Integer attachmentId;
    
    private String attachmentName;    // 原始文件名
    private String attachmentPath;    // 存储路径
    private String attachmentSize;    // 文件大小
    private String attachmentType;    // 文件类型: file/link/ai_tool
    private String attachmentUrl;     // 访问URL
    
    private Integer stageId;          // 所属阶段
    private Integer userId;           // 上传用户
}
