package com.txy.hanjiapeixun.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 阶段实体类
 */
@Data
@TableName("stage")
public class Stage {
    @TableId(type = IdType.AUTO)
    private Integer stageId;        // 阶段ID
    private String stageName;       // 阶段名称
    private String stageStarttime;  // 阶段开始时间
    private String stageEndtime;    // 阶段结束时间
}
