package com.txy.hanjiapeixun.entity;

import lombok.Data;

import java.util.List;

/**
 * 阶段扩展DTO（包含任务和附件信息）
 */
@Data
public class StageVO {
    // 阶段基本信息
    private Integer stageId;
    private String stageName;
    private String stageStarttime;
    private String stageEndtime;
    
    // 用户阶段信息
    private Integer score;        // 得分
    private String evaluation;    // 教师评价
    
    // 关联数据
    private List<TaskVO> tasks;           // 该阶段的任务列表
    private List<Attachment> attachments; // 附件列表
}
