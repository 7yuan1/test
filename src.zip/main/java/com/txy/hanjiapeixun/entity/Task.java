package com.txy.hanjiapeixun.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 任务实体类
 */
@Data
@TableName("task")
public class Task {
    
    @TableId(type = IdType.AUTO)
    private Integer taskId;           // 任务ID
    
    @TableField("task_title")
    private String taskTitle;         // 任务标题
    
    @TableField("task_desc")
    private String taskDesc;          // 任务描述
    
    @TableField("stage_id")
    private Integer stageId;          // 所属阶段ID
}
