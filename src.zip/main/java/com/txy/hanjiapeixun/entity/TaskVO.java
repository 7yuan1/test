package com.txy.hanjiapeixun.entity;

import lombok.Data;

/**
 * 任务扩展VO
 */
@Data
public class TaskVO {
    private Integer taskId;
    private String taskTitle;
    private String taskDesc;
    private Integer completed; // 是否完成：0-未完成，1-已完成
}
