package com.txy.hanjiapeixun.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 用户实体类
 * @TableName user 指定数据库表名
 */
@TableName(value = "user")
@Data
public class User {
    /**
     * 用户id
     * @TableId 指定主键，type = IdType.AUTO 表示自增
     */
    @TableId(type = IdType.AUTO)
    private Integer userId;

    /**
     * 用户名称
     */
    @TableField("user_name")
    private String userName;

    /**
     * 用户账号
     */
    @TableField("user_account")
    private String userAccount;

    /**
     * 用户密码
     */
    @TableField("user_password")
    private String userPassword;

    /**
     * 用户头像
     */
    @TableField("user_img")
    private String userImg;

    /**
     * 用户当前完成阶段
     */
    @TableField("stage_id")
    private Integer stageId;
}
