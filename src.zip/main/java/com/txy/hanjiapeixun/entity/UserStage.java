package com.txy.hanjiapeixun.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 用户阶段关联实体类
 */
@Data
@TableName("user_stage")
public class UserStage {
    
    @TableId(type = IdType.AUTO)
    private Integer id;               // 主键ID
    
    @TableField("user_id")
    private Integer userId;           // 用户ID
    
    @TableField("stage_id")
    private Integer stageId;          // 阶段ID
    
    @TableField("completed")
    private Integer completed;        // 是否完成：0-未完成，1-已完成
}
