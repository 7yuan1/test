package com.txy.hanjiapeixun.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

/**
 * 用户任务实体类
 * @TableName user_task 指定数据库表名
 */
@TableName(value = "user_task")
@Data
public class UserTask {
    /**
     * 主键ID
     * @TableId 指定主键，type = IdType.AUTO 表示自增
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 用户ID
     */
    @TableField("user_id")
    private Integer userId;

    /**
     * 任务ID
     */
    @TableField("task_id")
    private Integer taskId;

    /**
     * 是否完成：0-未完成，1-已完成
     */
    @TableField("completed")
    private Integer completed;
}