package com.txy.hanjiapeixun.interceptor;

import com.txy.hanjiapeixun.util.JwtUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 登录拦截器
 * 拦截需要认证的请求，验证Token
 */
@Slf4j
@Component
public class LoginInterceptor implements HandlerInterceptor {
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, 
                             Object handler) throws Exception {
        // 1. 获取请求路径
        String path = request.getRequestURI();
        log.info("拦截请求：{}", path);
        
        // 2. 获取Token（从请求头中获取）
        String token = request.getHeader("Authorization");
        
        // 3. 检查Token是否存在
        if (token == null || token.trim().isEmpty()) {
            log.warn("Token不存在，拒绝访问：{}", path);
            response.setStatus(401);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"code\":401,\"message\":\"请先登录\",\"data\":null}");
            return false;
        }
        
        // 4. 移除Bearer前缀（如果有）
        if (token.startsWith("Bearer ")) {
            token = token.substring(7);
        }
        
        // 5. 验证Token是否有效
        if (!jwtUtil.validateToken(token)) {
            log.warn("Token无效，拒绝访问：{}", path);
            response.setStatus(401);
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write("{\"code\":401,\"message\":\"Token无效或已过期\",\"data\":null}");
            return false;
        }
        
        // 6. 将用户信息存入请求属性（供后续使用）
        Integer userId = jwtUtil.getUserIdFromToken(token);
        String userName = jwtUtil.getUserNameFromToken(token);
        request.setAttribute("userId", userId);
        request.setAttribute("userName", userName);
        
        log.info("Token验证通过，用户：{}，ID：{}", userName, userId);
        return true;
    }
}
