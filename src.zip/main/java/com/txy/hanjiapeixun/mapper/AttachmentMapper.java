package com.txy.hanjiapeixun.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.txy.hanjiapeixun.entity.Attachment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * 附件Mapper接口
 */
@Mapper
public interface AttachmentMapper extends BaseMapper<Attachment> {
    
    /**
     * 根据阶段ID和用户ID查询附件列表
     * @param stageId 阶段ID
     * @param userId 用户ID
     * @return 附件列表
     */
    @Select("SELECT * FROM attachment WHERE stage_id = #{stageId} AND user_id = #{userId}")
    List<Attachment> selectByStageIdAndUserId(@Param("stageId") Integer stageId, 
                                               @Param("userId") Integer userId);
    
    /**
     * 根据任务ID查询附件列表
     * @param taskId 任务ID
     * @return 附件列表
     */
    @Select("SELECT * FROM attachment WHERE task_id = #{taskId}")
    List<Attachment> selectByTaskId(@Param("taskId") Integer taskId);
}
