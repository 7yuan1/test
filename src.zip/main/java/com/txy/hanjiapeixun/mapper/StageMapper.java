package com.txy.hanjiapeixun.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.txy.hanjiapeixun.entity.Stage;
import com.txy.hanjiapeixun.entity.StageVO;
import com.txy.hanjiapeixun.entity.TaskVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 阶段Mapper接口
 */
@Mapper
public interface StageMapper extends BaseMapper<Stage> {
    
    /**
     * 获取用户所有阶段数据（包含任务和用户完成状态）
     * @param userId 用户ID
     * @return 阶段列表（包含任务和附件信息）
     */
    List<StageVO> getUserStagesWithTasks(@Param("userId") Integer userId);
    
    /**
     * 获取阶段的任务列表（包含用户完成状态）
     * @param stageId 阶段ID
     * @param userId 用户ID
     * @return 任务列表
     */
    List<TaskVO> getTasksByStageAndUser(@Param("stageId") Integer stageId, 
                                        @Param("userId") Integer userId);
}
