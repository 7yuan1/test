package com.txy.hanjiapeixun.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.txy.hanjiapeixun.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 用户Mapper接口
 */
@Repository("hanjiaUserMapper")
@Mapper
public interface UserMapper extends BaseMapper<User> {
    
    /**
     * 根据账号查询用户
     * @param account 用户账号
     * @return 用户信息
     */
    @Select("SELECT * FROM user WHERE user_account = #{account}")
    User selectByAccount(@Param("account") String account);
    
    /**
     * 根据阶段ID查询用户列表
     * @param stageId 阶段ID
     * @return 用户列表
     */
    @Select("SELECT * FROM user WHERE stage_id = #{stageId}")
    List<User> selectByStageId(@Param("stageId") Integer stageId);
}
