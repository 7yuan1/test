package com.txy.hanjiapeixun.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.txy.hanjiapeixun.entity.UserTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 用户任务Mapper接口
 */
@Repository("userTaskMapper")
@Mapper
public interface UserTaskMapper extends BaseMapper<UserTask> {
    
    /**
     * 根据用户ID和阶段ID查询任务列表
     * 需要关联task表，因为user_task表中没有stage_id字段
     * @param userId 用户ID
     * @param stageId 阶段ID
     * @return 用户任务列表
     */
    @Select("SELECT ut.* FROM user_task ut " +
            "INNER JOIN task t ON ut.task_id = t.task_id " +
            "WHERE ut.user_id = #{userId} AND t.stage_id = #{stageId}")
    List<UserTask> selectByUserIdAndStageId(@Param("userId") Integer userId, @Param("stageId") Integer stageId);
}
