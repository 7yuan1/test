package com.txy.hanjiapeixun.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.txy.hanjiapeixun.entity.Attachment;

import java.util.List;

/**
 * 附件服务接口
 */
public interface AttachmentService extends IService<Attachment> {
    
    /**
     * 根据阶段ID查询附件列表
     * @param stageId 阶段ID
     * @return 附件列表
     */
    List<Attachment> listByStageId(int stageId);
    
    /**
     * 根据阶段ID和用户ID查询附件列表
     * @param stageId 阶段ID
     * @param userId 用户ID
     * @return 附件列表
     */
    List<Attachment> getByStageIdAndUserId(int stageId, Integer userId);
}
