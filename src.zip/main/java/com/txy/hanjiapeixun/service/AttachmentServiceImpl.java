package com.txy.hanjiapeixun.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.txy.hanjiapeixun.entity.Attachment;
import com.txy.hanjiapeixun.mapper.AttachmentMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AttachmentServiceImpl extends ServiceImpl<AttachmentMapper, Attachment>
        implements AttachmentService {

    @Override
    public List<Attachment> listByStageId(int stageId) {
        // 使用QueryWrapper查询指定阶段的附件
        QueryWrapper<Attachment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("stage_id", stageId);
        return this.baseMapper.selectList(queryWrapper);
    }
    
    @Override
    public List<Attachment> getByStageIdAndUserId(int stageId, Integer userId) {
        // 使用QueryWrapper查询指定阶段和用户的附件
        QueryWrapper<Attachment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("stage_id", stageId);
        if (userId != null) {
            queryWrapper.eq("user_id", userId);
        }
        return this.baseMapper.selectList(queryWrapper);
    }
}
