package com.txy.hanjiapeixun.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.txy.hanjiapeixun.entity.Stage;
import com.txy.hanjiapeixun.entity.StageVO;
import com.txy.hanjiapeixun.entity.TaskVO;

import java.util.List;

/**
 * 阶段服务接口
 */
public interface StageService extends IService<Stage> {
    
    /**
     * 获取用户所有阶段数据（包含任务完成状态和附件）
     * @param userId 用户ID
     * @return 阶段列表
     */
    List<StageVO> getUserStages(Integer userId);
    
    /**
     * 获取指定阶段的任务列表
     * @param stageId 阶段ID
     * @param userId 用户ID
     * @return 任务列表
     */
    List<TaskVO> getStageTasks(Integer stageId, Integer userId);
}
