package com.txy.hanjiapeixun.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.txy.hanjiapeixun.entity.Stage;
import com.txy.hanjiapeixun.entity.StageVO;
import com.txy.hanjiapeixun.entity.TaskVO;
import com.txy.hanjiapeixun.mapper.StageMapper;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 阶段服务实现类
 */
@Service("stageService")
public class StageServiceImpl extends ServiceImpl<StageMapper, Stage> implements StageService {
    
    @Override
    public List<StageVO> getUserStages(Integer userId) {
        return this.baseMapper.getUserStagesWithTasks(userId);
    }
    
    @Override
    public List<TaskVO> getStageTasks(Integer stageId, Integer userId) {
        return this.baseMapper.getTasksByStageAndUser(stageId, userId);
    }
}
