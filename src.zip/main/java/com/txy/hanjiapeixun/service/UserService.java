package com.txy.hanjiapeixun.service;
import com.baomidou.mybatisplus.extension.service.IService;
import com.txy.hanjiapeixun.entity.User;
import java.util.List;
public interface UserService extends IService<User> {
    /**
     * 根据账号查询用户
     */
    User getByAccount(String account);
    /**
     * 根据阶段查询用户
     */
    List<User> getByStageId(Integer stageId);
}