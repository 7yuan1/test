package com.txy.hanjiapeixun.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.txy.hanjiapeixun.entity.User;
import com.txy.hanjiapeixun.mapper.UserMapper;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 用户服务实现类
 */
@Service("hanjiaUserService")
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {
    
    @Override
    public User getByAccount(String account) {
        return this.baseMapper.selectByAccount(account);
    }
    
    @Override
    public List<User> getByStageId(Integer stageId) {
        return this.baseMapper.selectByStageId(stageId);
    }
}
