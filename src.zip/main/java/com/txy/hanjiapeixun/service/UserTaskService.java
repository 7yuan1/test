package com.txy.hanjiapeixun.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.txy.hanjiapeixun.entity.UserTask;

import java.util.List;

/**
 * 用户任务服务接口
 */
public interface UserTaskService extends IService<UserTask> {
    
    /**
     * 根据用户ID和任务ID查询用户任务
     * @param userId 用户ID
     * @param taskId 任务ID
     * @return 用户任务信息
     */
    UserTask getByUserIdAndTaskId(Integer userId, Integer taskId);
    
    /**
     * 根据用户ID和阶段ID查询任务列表
     * @param userId 用户ID
     * @param stageId 阶段ID
     * @return 用户任务列表
     */
    List<UserTask> getByUserIdAndStageId(Integer userId, Integer stageId);
    
    /**
     * 更新任务状态（存在则更新，不存在则新增）
     * @param userId 用户ID
     * @param taskId 任务ID
     * @param completed 完成状态
     * @return 是否成功
     */
    boolean updateTaskStatus(Integer userId, Integer taskId, Integer completed);
}
