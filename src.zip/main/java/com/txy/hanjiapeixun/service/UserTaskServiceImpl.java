package com.txy.hanjiapeixun.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.txy.hanjiapeixun.entity.UserTask;
import com.txy.hanjiapeixun.mapper.UserTaskMapper;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 用户任务服务实现类（含LambdaUpdateWrapper）
 */
@Service("userTaskService")
public class UserTaskServiceImpl extends ServiceImpl<UserTaskMapper, UserTask> implements UserTaskService {
    
    @Override
    public UserTask getByUserIdAndTaskId(Integer userId, Integer taskId) {
        LambdaQueryWrapper<UserTask> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(UserTask::getUserId, userId)
               .eq(UserTask::getTaskId, taskId);
        return this.getOne(wrapper);
    }
    
    @Override
    public List<UserTask> getByUserIdAndStageId(Integer userId, Integer stageId) {
        // 注意：user_task表中没有stage_id字段，需要通过关联task表查询
        // 这里使用自定义SQL，需要在Mapper中定义
        return this.baseMapper.selectByUserIdAndStageId(userId, stageId);
    }
    
    @Override
    public boolean updateTaskStatus(Integer userId, Integer taskId, Integer completed) {
        // 先查询是否存在
        UserTask existing = getByUserIdAndTaskId(userId, taskId);
        if (existing != null) {
            // 存在则更新
            existing.setCompleted(completed);
            return this.updateById(existing);
        } else {
            // 不存在则新增
            UserTask newUserTask = new UserTask();
            newUserTask.setUserId(userId);
            newUserTask.setTaskId(taskId);
            newUserTask.setCompleted(completed);
            return this.save(newUserTask);
        }
    }
}
