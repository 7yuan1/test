package com.txy.hanjiapeixun.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 统一响应封装类
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Result<T> {
    private int code; // 状态码：200成功，401未登录，404未找到，500错误
    private String message; // 消息
    private T data; // 响应数据

    // 成功无数据
    public static <T> Result<T> success() {
        return new Result<>(200, "操作成功", null);
    }

    // 成功带数据
    public static <T> Result<T> success(T data) {
        return new Result<>(200, "操作成功", data);
    }

    // 成功自定义消息+数据
    public static <T> Result<T> success(String msg, T data) {
        return new Result<>(200, msg, data);
    }

    // 默认失败
    public static <T> Result<T> error() {
        return new Result<>(500, "操作失败", null);
    }

    // 失败自定义消息
    public static <T> Result<T> error(String msg) {
        return new Result<>(500, msg, null);
    }

    // 失败自定义状态码+消息
    public static <T> Result<T> error(int code, String msg) {
        return new Result<>(code, msg, null);
    }
}
