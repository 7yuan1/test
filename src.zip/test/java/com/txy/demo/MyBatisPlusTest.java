package com.txy.demo;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.txy.demo.demos.web.User;
import com.txy.demo.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * MyBatis-Plus CRUD测试类
 */
@SpringBootTest(classes = com.txy.demo.DemoApplication.class)
public class MyBatisPlusTest {
    @Autowired
    private UserMapper userMapper;
/**
 * 测试插入数据
 */
@Test
public void testInsert() {
    System.out.println("========== 测试插入数据 ==========");
// 创建用户对象
    User user = new User();
    user.setName("李四");
    user.setUserAccount("lisi");
    user.setUserPassword("123456");
    user.setStageId(1);
// 调用insert方法
    int rows = userMapper.insert(user);
    System.out.println("插入结果: " + (rows > 0 ? "成功" : "失败"));
    System.out.println("生成的主键ID: " + user.getUserId());
}
    /**
     * 测试根据ID查询
     */
    @Test
    public void testSelectById() {
        System.out.println("========== 测试根据ID查询 ==========");
        Integer id = 1;
        User user = userMapper.selectById(id);
        if (user != null) {
            System.out.println("查询结果:");
            System.out.println(" userId: " + user.getUserId());
            System.out.println(" name: " + user.getName());
            System.out.println(" userAccount: " + user.getUserAccount());
            System.out.println(" stageId: " + user.getStageId());
        } else {
            System.out.println("未找到ID为 " + id + " 的用户");
        }
    }
    /**
     * 测试查询所有
     */
    @Test
    public void testSelectList() {
        System.out.println("========== 测试查询所有 ==========");
// 查询所有
        List<User> userList = userMapper.selectList(null);
        System.out.println("共查询到 " + userList.size() + " 条记录");
        for (User user : userList) {
            System.out.println(" " + user.getUserId() + " - " +
                    user.getName() + " - " + user.getUserAccount());
        }
    }
/**
 * 测试条件查询 - QueryWrapper
 */
@Test
public void testSelectByWrapper() {
    System.out.println("========== 测试条件查询(QueryWrapper) ==========");
// 创建条件构造器
    QueryWrapper<User> wrapper = new QueryWrapper<>();
// 设置查询条件：stage_id = 3 并且 user_name like '%张%'
    wrapper.eq("stage_id", 3)
            .like("user_name", "张");
    List<User> userList = userMapper.selectList(wrapper);
    System.out.println("符合条件的有 " + userList.size() + " 条记录");
    for (User user : userList) {
        System.out.println(" " + user.getUserId() + " - " +
                user.getName() + " - 阶段:" + user.getStageId());
    }
}
    /**
     * 测试条件查询 - LambdaQueryWrapper
     */
    @Test
    public void testSelectByLambdaWrapper() {
        System.out.println("========== 测试条件查询(LambdaQueryWrapper) ==========");
// Lambda条件构造器（避免硬编码字段名）
                LambdaQueryWrapper<User> lambdaWrapper = new LambdaQueryWrapper<>();
        lambdaWrapper.eq(User::getStageId, 3)
                .like(User::getName, "张");
        List<User> userList = userMapper.selectList(lambdaWrapper);
        System.out.println("符合条件的有 " + userList.size() + " 条记录");
        for (User user : userList) {
            System.out.println(" " + user.getUserId() + " - " +
                    user.getName() + " - 阶段:" + user.getStageId());
        }
    }
    /**
     * 测试根据Map查询
     */
    @Test
    public void testSelectByMap() {
        System.out.println("========== 测试根据Map查询 ==========");
// 构建查询条件
        Map<String, Object> columnMap = new HashMap<>();
        columnMap.put("stage_id", 1);
        columnMap.put("user_name", "李四");
        List<User> userList = userMapper.selectByMap(columnMap);
        System.out.println("符合条件的有 " + userList.size() + " 条记录");
    }
    /**
     * 测试批量查询
     */
    @Test
    public void testSelectBatchIds() {
        System.out.println("========== 测试批量查询 ==========");
        List<Integer> idList = Arrays.asList(1, 2, 3);
        List<User> userList = userMapper.selectBatchIds(idList);
        System.out.println("批量查询到 " + userList.size() + " 条记录");
    }
/**
 * 测试统计总数
 */
    @Test
    public void testSelectCount() {
        System.out.println("========== 测试统计总数 ==========");
// 统计所有
        Long totalCount = userMapper.selectCount(null);
        System.out.println("用户总数: " + totalCount);
// 统计条件
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getStageId, 3);
        Long count = userMapper.selectCount(wrapper);
        System.out.println("阶段3的用户数: " + count);
    }
    /**
     * 测试更新 - 根据ID更新
     */
    @Test
    public void testUpdateById() {
        System.out.println("========== 测试根据ID更新 ==========");
// 先查询
        User user = userMapper.selectById(1);
        System.out.println("更新前: " + user.getName() + " - 阶段:" +
                user.getStageId());
// 修改数据
        user.setStageId(4);
// 执行更新
        int rows = userMapper.updateById(user);
        System.out.println("更新结果: " + (rows > 0 ? "成功" : "失败"));
// 重新查询验证
        User updatedUser = userMapper.selectById(1);
        System.out.println("更新后: " + updatedUser.getName() + " - 阶段:" +
                updatedUser.getStageId());
    }
    /**
     * 测试更新 - 使用UpdateWrapper
     */
    @Test
    public void testUpdateByWrapper() {
        System.out.println("========== 测试使用UpdateWrapper更新 ==========");
// 创建更新条件
        UpdateWrapper<User> updateWrapper = new UpdateWrapper<>();
        updateWrapper.eq("user_account", "lisi") // 条件：user_account = 'lisi'
                .set("stage_id", 2) // 设置：stage_id = 2
                .set("user_name", "李四四"); // 设置：user_name = '李四四'
// 执行更新（不需要实体，直接使用updateWrapper）
        int rows = userMapper.update(null, updateWrapper);
        System.out.println("更新了 " + rows + " 条记录");
    }
    /**
     * 测试删除 - 根据ID删除
     */
    @Test
    public void testDeleteById() {
        System.out.println("========== 测试根据ID删除 ==========");
// 先插入一条测试数据
        User user = new User();
        user.setName("测试用户");
        user.setUserAccount("test");
        user.setUserPassword("123456");
        userMapper.insert(user);
        Integer id = user.getUserId();
        System.out.println("插入测试用户, ID: " + id);
// 删除
        int rows = userMapper.deleteById(id);
        System.out.println("删除结果: " + (rows > 0 ? "成功" : "失败"));
// 验证
        User deletedUser = userMapper.selectById(id);
        System.out.println("验证查询结果: " + (deletedUser == null ? "已删除" : "还存在"));
    }
    /**
     * 测试删除 - 条件删除
     */
    @Test
    public void testDeleteByWrapper() {
        System.out.println("========== 测试条件删除 ==========");
// 创建删除条件
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getUserAccount, "lisi");
// 执行删除
        int rows = userMapper.delete(wrapper);
        System.out.println("删除了 " + rows + " 条记录");
    }
}