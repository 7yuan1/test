package com.txy.hanjiapeixun;

import com.txy.hanjiapeixun.util.JwtUtil;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class JwtTest {
    
    @Autowired
    private JwtUtil jwtUtil;
    
    @Test
    public void testGenerateToken() {
        // 生成 Token
        String token = jwtUtil.generateToken(1, "张三");
        System.out.println("生成的Token：");
        System.out.println(token);
        
        // 验证 Token
        boolean valid = jwtUtil.validateToken(token);
        System.out.println("Token是否有效：" + valid);
        
        // 解析用户ID
        Integer userId = jwtUtil.getUserIdFromToken(token);
        System.out.println("用户ID：" + userId);
        
        // 解析用户名
        String userName = jwtUtil.getUserNameFromToken(token);
        System.out.println("用户名：" + userName);
    }
    
    @Test
    public void testValidateInvalidToken() {
        // 测试无效 Token
        String invalidToken = "invalid.token.here";
        boolean valid = jwtUtil.validateToken(invalidToken);
        System.out.println("无效Token是否有效：" + valid);
    }
    
    @Test
    public void testRefreshToken() {
        // 生成原始 Token
        String originalToken = jwtUtil.generateToken(1, "张三");
        System.out.println("原始Token：" + originalToken);
        
        // 刷新 Token
        String refreshedToken = jwtUtil.refreshToken(originalToken);
        System.out.println("刷新后的Token：" + refreshedToken);
        
        // 验证新 Token
        boolean valid = jwtUtil.validateToken(refreshedToken);
        System.out.println("刷新后的Token是否有效：" + valid);
        
        // 解析用户信息
        Integer userId = jwtUtil.getUserIdFromToken(refreshedToken);
        String userName = jwtUtil.getUserNameFromToken(refreshedToken);
        System.out.println("用户ID：" + userId + ", 用户名：" + userName);
    }
}
