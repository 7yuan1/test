// utils/api.js
// AI服务地址配置
const configuredAiUrl = 'http://10.156.216.185:8888';
const AI_BASE_URL = configuredAiUrl.includes('你的') ? 'http://localhost:5000' : configuredAiUrl;

/**
 * 上传文件到AI服务并获取评分（包含Mock数据支持）
 * @param {string} filePath - 本地文件路径
 * @returns {Promise} - 返回包含score和commentDetails的对象
 */
export const uploadAndScore = (filePath) => {
  console.log('=== uploadAndScore AI分析 ===');
  console.log('AI服务地址:', AI_BASE_URL);
  console.log('上传文件路径:', filePath);
  
  // 检查是否使用mock数据
  const useMock = configuredAiUrl.includes('你的');
  
  if (useMock) {
    // 使用mock数据模拟AI分析
    console.log('使用Mock数据进行AI分析');
    return new Promise((resolve) => {
      setTimeout(() => {
        const mockResult = {
          score: Math.floor(Math.random() * 20) + 80, // 80-100分
          commentDetails: {
            '内容完整性': '文档内容完整，覆盖了主要需求点',
            '格式规范性': '格式规范，易于阅读',
            '技术深度': '技术分析较为深入，论证充分',
            '创新性': '具有一定的创新性和独特见解'
          }
        };
        console.log('AI分析Mock结果:', mockResult);
        resolve(mockResult);
      }, 1000);
    });
  }
  
  return new Promise((resolve, reject) => {
    wx.uploadFile({
      url: AI_BASE_URL + '/upload',
      filePath: filePath,
      name: 'file',
      success: (res) => {
        console.log('AI服务响应:', res.data);
        
        try {
          const data = JSON.parse(res.data);
          if (data.code === 200) {
            // AI服务返回格式: { score: 85, commentDetails: { ... } }
            console.log('AI分析成功 - 评分:', data.data.score);
            resolve(data.data);
          } else {
            console.error('AI分析失败 - 错误码:', data.code, ', 错误信息:', data.msg);
            wx.showToast({ title: data.msg || 'AI分析失败', icon: 'none' });
            reject(data);
          }
        } catch (e) {
          console.error('AI服务响应解析失败:', e);
          wx.showToast({ title: 'AI服务响应解析失败', icon: 'none' });
          reject(e);
        }
      },
      fail: (err) => {
        console.error('AI服务连接失败:', err);
        wx.showToast({ title: 'AI服务连接失败，请检查AI服务是否启动', icon: 'none' });
        reject(err);
      }
    });
  });
};
