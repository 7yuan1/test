// utils/request.js

// 后端服务地址配置（使用Mock模式，需在开发者工具中关闭域名校验或在公众平台配置域名）
const configuredBaseUrl = 'http://你的SpringBoot服务IP:端口'; // 切换为占位符以启用Mock
const BASE_URL = configuredBaseUrl.includes('你的') ? 'http://localhost:8080' : configuredBaseUrl;

// Mock数据（用于开发测试，后端未启动时使用）
const mockData = {
  '/api/stages': [
    { id: 1, name: '需求分析', completedTasks: 0, totalTasks: 3 },
    { id: 2, name: '系统设计', completedTasks: 0, totalTasks: 3 },
    { id: 3, name: '代码实现', completedTasks: 0, totalTasks: 4 },
    { id: 4, name: '测试验收', completedTasks: 0, totalTasks: 2 }
  ],
  '/api/stage/detail': {
    id: 1,
    name: '需求分析',
    description: '完成项目需求分析和文档编写',
    aiScore: null,
    aiComment: null,
    tasks: [
      { id: 1, name: '收集用户需求', description: '与导师沟通，明确需求', completed: false },
      { id: 2, name: '编写需求文档', description: '撰写需求规格说明书', completed: false },
      { id: 3, name: '需求评审', description: '组织需求评审会议', completed: false }
    ]
  },
  '/api/task/update': { success: true },
  '/api/ai/save-score': { success: true }
};

export const request = (options) => {
  const token = wx.getStorageSync('token');
  console.log('=== request 请求 ===');
  console.log('请求 URL:', BASE_URL + options.url);
  console.log('请求方法:', options.method || 'GET');
  console.log('请求数据:', options.data);
  
  // 检查是否使用mock数据
  const useMock = configuredBaseUrl.includes('你的');
  
  return new Promise((resolve, reject) => {
    if (useMock) {
      // 使用mock数据
      console.log('使用Mock数据');
      let mockResponse = null;
      
      if (options.url === '/api/stages') {
        mockResponse = mockData['/api/stages'];
      } else if (options.url.startsWith('/api/stage/detail')) {
        mockResponse = { ...mockData['/api/stage/detail'] };
      } else if (options.url === '/api/task/update') {
        mockResponse = mockData['/api/task/update'];
      } else if (options.url === '/api/ai/save-score') {
        mockResponse = mockData['/api/ai/save-score'];
      }
      
      if (mockResponse) {
        setTimeout(() => {
          console.log('Mock响应:', mockResponse);
          resolve(mockResponse);
        }, 500);
      } else {
        reject({ code: 404, msg: '接口未找到' });
      }
      return;
    }
    
    wx.request({
      url: BASE_URL + options.url,
      method: options.method || 'GET',
      data: options.data || {},
      header: {
        'content-type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {})
      },
      success: (res) => {
        console.log('请求成功 - 状态码:', res.statusCode);
        console.log('响应数据:', res.data);
        
        if (!res.data) {
          console.error('响应数据为空');
          wx.showToast({ title: '服务器响应异常', icon: 'none' });
          reject({ code: 500, msg: '服务器响应异常' });
          return;
        }
        
        if (res.statusCode === 200 && res.data.code === 200) {
          resolve(res.data.data);
        } else {
          console.error('请求失败 - 错误码:', res.data.code, ', 错误信息:', res.data.msg);
          if (res.data.code === 401) {
            wx.removeStorageSync('token');
            wx.redirectTo({ url: '/pages/login/login' });
          } else {
            wx.showToast({ title: res.data.msg || '请求失败', icon: 'none' });
          }
          reject(res.data);
        }
      },
      fail: (err) => {
        console.error('网络请求失败:', err);
        wx.showToast({ title: '网络连接失败，请检查后端服务是否启动', icon: 'none' });
        reject(err);
      }
    });
  });
};

// 专门用于文件上传（Spring Boot）
export const uploadFile = (filePath, formData) => {
  const token = wx.getStorageSync('token');
  console.log('=== uploadFile 文件上传 ===');
  console.log('上传 URL:', BASE_URL + '/api/file/upload');
  console.log('文件路径:', filePath);
  console.log('表单数据:', formData);
  
  // 检查是否使用mock数据
  const useMock = configuredBaseUrl.includes('你的');
  
  if (useMock) {
    // 使用mock数据模拟文件上传
    console.log('使用Mock数据进行文件上传');
    return new Promise((resolve) => {
      setTimeout(() => {
        const mockResult = {
          fileName: 'uploaded_file_' + Date.now() + '.pdf',
          stageId: formData.stageId,
          userId: formData.userId,
          success: true
        };
        console.log('文件上传Mock结果:', mockResult);
        resolve(mockResult);
      }, 500);
    });
  }
  
  return new Promise((resolve, reject) => {
    wx.uploadFile({
      url: BASE_URL + '/api/file/upload',
      filePath: filePath,
      name: 'file',          // 后端接收文件的参数名
      formData: formData,    // 包含 stageId, userId
      header: {
        'Authorization': token ? `Bearer ${token}` : ''
      },
      success: (res) => {
        console.log('文件上传成功:', res.data);
        const data = JSON.parse(res.data);
        if (data.code === 200) {
          resolve(data.data);
        } else {
          console.error('文件上传失败:', data.msg);
          wx.showToast({ title: data.msg || '上传失败', icon: 'none' });
          reject(data);
        }
      },
      fail: (err) => {
        console.error('文件上传失败:', err);
        wx.showToast({ title: '上传失败', icon: 'none' });
        reject(err);
      }
    });
  });
};