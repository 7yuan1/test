// utils/api.js
const AI_BASE_URL = 'http://你的Flask服务IP:端口'; // 例如 http://192.168.1.100:5000

// 上传文件到 AI 并获取评分
export const uploadAndScore = (filePath) => {
  return new Promise((resolve, reject) => {
    wx.uploadFile({
      url: AI_BASE_URL + '/upload',
      filePath: filePath,
      name: 'file',
      success: (res) => {
        try {
          const result = JSON.parse(res.data);
          // 假设 AI 返回格式 { score: 85, commentDetails: {...} }
          resolve(result);
        } catch (e) {
          reject(e);
        }
      },
      fail: (err) => reject(err)
    });
  });
};